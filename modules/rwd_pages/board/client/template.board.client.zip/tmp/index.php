<script>
var str = '%E4%B8%80%E4%B8%B2%E4%B8%AD%E6%96%87%E5%AD%97';
console.log(decodeURIComponent(str));

</script>

<?php

$str = "一串中文字";
print urlencode($str);

